function Pow(x,a){
    return Math.pow(x,a);
}

function Modulo(a,b){
    return a%b;
}

module.exports = {
    Pow,
    Modulo
}